﻿using System;
using System.Linq.Expressions;
using System.Net.Http.Headers;

namespace ClassLibrary_FootballPlayer
{
    public class FootballPlayer
    {
        public int _id;
        private string _name;
        private double _price;
        private int _shirtNumber;
        
        public int Id
        {
            get => _id;
            set
            {
                _id = value;
            }
        }
        public string Name
        {
            get => _name;
            set
            {
                if (value == null) throw new ArgumentNullException();
                if (value.Length < 4) throw new ArgumentException();
                _name = value;
            }
        }

        public double Price
        {
            get => _price;
            set
            {
                if (value <= 0) throw new ArgumentOutOfRangeException();
                _price = value;
            }
        }

        public int ShirtNumber
        {
            get => _shirtNumber;
            set
            {
                if ((value < 1) || (value > 100)) throw new ArgumentOutOfRangeException();
                _shirtNumber = value;
            }
        }

        public FootballPlayer(int id, string name, double price, int shirtNumber)
        {
            Id = id;
            Name = name;
            Price = price;
            ShirtNumber = shirtNumber;

        }


        public override string ToString()
        {
            return $"{nameof(Id)}: {Id}, {nameof(Name)}: {Name}, {nameof(Price)}: {Price}, {nameof(ShirtNumber)}: {ShirtNumber}";
        }
    }
}
