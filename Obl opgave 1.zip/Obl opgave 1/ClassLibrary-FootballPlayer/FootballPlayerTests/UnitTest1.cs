using System;
using ClassLibrary_FootballPlayer;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace FootballPlayerTests
{
    [TestClass]
    public class UnitTest1
    {
        private FootballPlayer _footballPlayer;

        [TestInitialize]
        public void TestPerson()
        {
            _footballPlayer = new FootballPlayer(1, "Stig T�fting", 1000000, 9);
        }
        [TestMethod]
        public void ConstructorTest()
        {
            Assert.ThrowsException<ArgumentNullException>(() => new FootballPlayer(1,null,1000000, 9));
            Assert.ThrowsException<ArgumentException>((() => new FootballPlayer(1,"", 1000000,9)));
        }

        [TestMethod]
        public void IdTest()
        {
            FootballPlayer fp = _footballPlayer;

            Assert.AreEqual(1,fp.Id);
            


        }
        [TestMethod]
        public void NameTest()
        {
            FootballPlayer fp = _footballPlayer;
            
            Assert.AreEqual("Stig T�fting", fp.Name);

            Assert.ThrowsException<ArgumentException>((() => fp.Name = "Bob"));
            Assert.ThrowsException<ArgumentNullException>((() => fp.Name = null));
        }

        [TestMethod]
        public void PriceTest()
        {
            FootballPlayer fp = _footballPlayer;
            
            Assert.AreEqual(1000000, fp.Price);

            fp.Price = 1;
            Assert.AreEqual(1, fp.Price);

            Assert.ThrowsException<ArgumentOutOfRangeException>((() => fp.Price = 0));
        }

        [TestMethod]
        public void ShirtNumberTest()
        {
            FootballPlayer fp = _footballPlayer;
            Assert.AreEqual(9,fp.ShirtNumber);

            fp.ShirtNumber = 100;
            Assert.AreEqual(100, fp.ShirtNumber);

            fp.ShirtNumber = 50;
            Assert.AreEqual(50, fp.ShirtNumber);

            Assert.ThrowsException<ArgumentOutOfRangeException>((() => fp.ShirtNumber = 0));
            Assert.ThrowsException<ArgumentOutOfRangeException>((() => fp.ShirtNumber = 101));

        }
        [TestMethod]
        public void TestToString()
        {
            Assert.AreEqual("Id: 1, Name: Stig T�fting, Price: 1000000, ShirtNumber: 9", _footballPlayer.ToString());
        }

    }
}
